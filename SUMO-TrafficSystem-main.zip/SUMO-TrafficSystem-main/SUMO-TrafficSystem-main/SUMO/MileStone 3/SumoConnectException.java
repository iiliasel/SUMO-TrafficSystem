public class SumoConnectException extends Exception {
    public SumoConnectException(String message) {
        super(message);
    }
}