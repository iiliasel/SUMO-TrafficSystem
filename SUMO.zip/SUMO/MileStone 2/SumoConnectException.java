// 自定义异常：SUMO连接相关异常
public class SumoConnectException extends Exception {
    public SumoConnectException(String message) {
        super(message);
    }
}